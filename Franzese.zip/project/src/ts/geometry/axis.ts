export enum Axis{
    X = "X", Y = "Y", Z = "Z"
}