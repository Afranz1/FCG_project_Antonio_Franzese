export default class PerformedTransformation {

    /**
     * The subject that is transformed
     */
    readonly who: string
}